<?php

//predefined php -- add this to your code
function i0(){

    if(!empty($_SERVER[base64_decode('U0VSVkVSX05BTUU=')])){
        $m1=$_SERVER[base64_decode('U0VSVkVSX05BTUU=')];
    }else{
        $m1=$_SERVER[base64_decode('U0VSVkVSX05BTUU=')];
    }
    return base64_encode($m1);
}

//To use the function above, just call it. e.g.
//echo i0();

//add the return value to post parameters
//userid, amount and secretkey (the echo value/content on line 7 above)



?>